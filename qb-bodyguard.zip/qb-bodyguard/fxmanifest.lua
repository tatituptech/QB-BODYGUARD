fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'QBCore Bodyguard Menu Script'
version '1.0.0'

client_scripts {
    'bodyguard.lua'
}

dependencies {
    'qb-core',
    'qb-menu'
}