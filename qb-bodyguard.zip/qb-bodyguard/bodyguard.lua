local QBCore = exports['qb-core']:GetCoreObject()

local gangs = {
    ballas = {
        models = {
            "g_m_y_ballaeast_01", 
            "g_m_y_ballaorig_01", 
            "g_m_y_ballasout_01"
        }, 
        weapon = "weapon_assaultrifle", 
        label = "Crip"
    },
    family = {
        models = {
            "g_m_y_famca_01", 
            "g_m_y_famdnf_01", 
            "g_m_y_famfor_01"
        }, 
        weapon = "weapon_assaultrifle", 
        label = "Blood"
    },
    vago = {
        models = {
            "g_m_y_mexgoon_01", 
            "g_m_y_mexgoon_02", 
            "g_m_y_mexgoon_03"
        }, 
        weapon = "weapon_assaultrifle", 
        label = "Vato"
    },
    mara = {
        models = {
            "g_m_y_mexgang_01", 
            "g_m_y_mexgang_02",
            "g_m_y_mexgang_03"
        }, 
        weapon = "weapon_assaultrifle", 
        label = "Mafia"
    },
    lost = {
        models = {
            "g_m_y_lost_01", 
            "g_m_y_lost_02", 
            "g_m_y_lost_03"
        }, 
        weapon = "weapon_assaultrifle", 
        label = "Lost"
    },
}

local maxBodyguards = 5
local bodyguards = {}
local followDistance = 0.8 -- Closer follow distance

local function LoadModel(modelName)
    local modelHash = GetHashKey(modelName)
    RequestModel(modelHash)
    
    local timeout = 0
    while not HasModelLoaded(modelHash) and timeout < 100 do
        Wait(50)
        timeout = timeout + 1
    end
    
    if not HasModelLoaded(modelHash) then
        print("^1[BODYGUARD ERROR] Failed to load model: " .. modelName .. "^7")
        return nil
    end
    
    return modelHash
end

local function SpawnBodyguard(gang)
    if #bodyguards >= maxBodyguards then 
        return QBCore.Functions.Notify('Max bodyguards reached!', 'error') 
    end
    
    local gangData = gangs[gang]
    if not gangData then 
        return QBCore.Functions.Notify('Invalid gang selected!', 'error')
    end
    
    -- Get random model from the gang
    local randomModel = gangData.models[math.random(#gangData.models)]
    print("^3[BODYGUARD] Spawning " .. gangData.label .. " with model: " .. randomModel .. "^7")
    
    local modelHash = LoadModel(randomModel)
    if not modelHash then
        return QBCore.Functions.Notify('Failed to load gang model!', 'error')
    end
    
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local playerHeading = GetEntityHeading(playerPed)
    
    -- Spawn around the player in a circle
    local angle = math.rad(math.random(0, 360))
    local distance = 1.5 -- Spawn distance from player
    
    local spawnX = playerCoords.x + math.cos(angle) * distance
    local spawnY = playerCoords.y + math.sin(angle) * distance
    local spawnZ = playerCoords.z
    
    -- Ensure the ground is found
    local groundZ = playerCoords.z
    local found = false
    for i = playerCoords.z, playerCoords.z - 100, -1 do
        if GetGroundZFor_3dCoord(spawnX, spawnY, i, groundZ, false) then
            found = true
            spawnZ = groundZ
            break
        end
    end
    
    -- Create the ped
    local ped = CreatePed(26, modelHash, spawnX, spawnY, spawnZ, playerHeading, true, false)
    
    if not DoesEntityExist(ped) then
        print("^1[BODYGUARD ERROR] Failed to create ped^7")
        ReleaseModelAndDisburden(modelHash)
        return QBCore.Functions.Notify('Failed to spawn bodyguard!', 'error')
    end
    
    -- Ensure ped is not colliding with player
    while #(GetEntityCoords(ped) - playerCoords) < 0.5 do
        Wait(10)
        SetEntityCoords(ped, spawnX, spawnY, spawnZ, false, false, false, false)
    end
    
    -- Set up the bodyguard
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedAsGroupMember(ped, GetPedGroupIndex(playerPed))
    SetPedNeverLeavesGroup(ped, true)
    
    -- Give automatic weapon with ammo
    GiveWeaponToPed(ped, GetHashKey(gangData.weapon), 500, false, true)
    SetPedDropsWeaponsWhenDead(ped, false)
    
    -- Combat settings
    SetPedCombatAbility(ped, 100)
    SetPedCombatMovement(ped, 2)
    SetPedFleeAttributes(ped, 0, false)
    
    -- Health
    SetEntityAsMissionEntity(ped, true, true)
    SetPedMaxHealth(ped, 300)
    SetEntityHealth(ped, 300)
    
    -- Release model from memory
    ReleaseModelAndDisburden(modelHash)
    
    table.insert(bodyguards, {ped = ped, gang = gang, spawned = GetGameTimer()})
    print("^2[BODYGUARD SUCCESS] " .. gangData.label .. " bodyguard spawned with assault rifle! Total: " .. #bodyguards .. "^7")
    QBCore.Functions.Notify(gangData.label .. ' bodyguard spawned with assault rifle!', 'success')
end

local function DismissBodyguards()
    for _, bodyguard in pairs(bodyguards) do
        if DoesEntityExist(bodyguard.ped) then 
            DeleteEntity(bodyguard.ped) 
        end
    end
    bodyguards = {}
    print("^3[BODYGUARD] All bodyguards dismissed^7")
    QBCore.Functions.Notify("All bodyguards dismissed", 'primary')
end

-- Cleanup dead bodyguards
Citizen.CreateThread(function()
    while true do 
        Wait(2000)
        for i = #bodyguards, 1, -1 do
            if not DoesEntityExist(bodyguards[i].ped) or IsEntityDead(bodyguards[i].ped) then
                print("^3[BODYGUARD] Removing dead bodyguard^7")
                table.remove(bodyguards, i)
            end
        end
    end
end)

-- Make bodyguards follow closer and fight nearby enemies
Citizen.CreateThread(function()
    while true do
        Wait(100)
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        
        for _, bodyguard in ipairs(bodyguards) do
            if DoesEntityExist(bodyguard.ped) and not IsEntityDead(bodyguard.ped) then
                local bodyguardCoords = GetEntityCoords(bodyguard.ped)
                local distance = #(bodyguardCoords - playerCoords)
                
                -- Keep bodyguard close to player
                if distance > followDistance then
                    TaskGoToEntity(bodyguard.ped, playerPed, -1, followDistance, 2.0, 1073741824, 0)
                else
                    ClearTasksImmediately(bodyguard.ped)
                end
                
                -- Combat system - check for nearby threats
                local peds = GetGamePool('CPed')
                for _, ped in ipairs(peds) do
                    if ped ~= playerPed and ped ~= bodyguard.ped then
                        if DoesEntityExist(ped) and not IsEntityDead(ped) then
                            local pedDistance = #(GetEntityCoords(bodyguard.ped) - GetEntityCoords(ped))
                            if pedDistance < 30 then
                                if IsPedAPlayer(ped) == false and not IsPedInGroup(ped, GetPedGroupIndex(playerPed)) then
                                    TaskCombatPed(bodyguard.ped, ped, 0, 16)
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end)

RegisterCommand('bodyguard', function()
    local menu = {
        {header = "Bodyguard Menu", isMenuHeader = true},
        {header = "Spawn Crip Bodyguard", txt = "Random Crip Member (" .. #bodyguards .. "/" .. maxBodyguards .. ")", params = {event = "bodyguard:spawn", args = "ballas"}},
        {header = "Spawn Blood Bodyguard", txt = "Random Blood Member (" .. #bodyguards .. "/" .. maxBodyguards .. ")", params = {event = "bodyguard:spawn", args = "family"}},
        {header = "Spawn Vato Bodyguard", txt = "Random Vato Member (" .. #bodyguards .. "/" .. maxBodyguards .. ")", params = {event = "bodyguard:spawn", args = "vago"}},
        {header = "Spawn Mafia Bodyguard", txt = "Random Mafia Member (" .. #bodyguards .. "/" .. maxBodyguards .. ")", params = {event = "bodyguard:spawn", args = "mara"}},
        {header = "Spawn Lost Bodyguard", txt = "Random Lost Member (" .. #bodyguards .. "/" .. maxBodyguards .. ")", params = {event = "bodyguard:spawn", args = "lost"}},
        {header = "Dismiss All Bodyguards", txt = "Remove all active bodyguards", params = {event = "bodyguard:dismiss"}}
    }
    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent("bodyguard:spawn", function(gang)
    SpawnBodyguard(gang)
end)

RegisterNetEvent("bodyguard:dismiss", function()
    DismissBodyguards()
end)

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        for _, bodyguard in ipairs(bodyguards) do
            if DoesEntityExist(bodyguard.ped) then
                DeleteEntity(bodyguard.ped)
            end
        end
    end
end)